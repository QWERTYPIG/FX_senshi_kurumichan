# LightGBM A/B Feature Ablation Experiment

This is a drop-in version of the current project files. It keeps the same
LightGBM parameters and walk-forward split logic, but supports two feature sets:

- `A`: original 14 features
- `B`: A plus `intraday_lag2`, `intraday_lag3`, `return_lag2`, `return_lag3`

Put these files together in your existing model folder (back up the originals).

```bash
python train.py --feature-set A --train-end 2026-11-06
python train.py --feature-set B --train-end 2026-11-06
```

Defaults: A saves to `artifacts_A/`, B to `artifacts_B/`.
Set identical `--train-end`, `--cv-folds`, `--valid-days`, `--test-days`,
`--early-stop-days`, and `--min-train-days` for a fair comparison.

Compare `artifacts_A/metrics.json` and `artifacts_B/metrics.json`, focusing on
`validation.score` first; leave `test.score` for a final independent check.

After the model is trained, pass the corresponding artifacts directory:

```bash
python predict.py --artifacts-dir artifacts_B --date 2026-11-09 --output prediction_B.csv
```

Replace the sample date with the real future trading date. The prediction target
must be later than the `trained_through` date saved in metadata. Training should
use only labels known as of that time.

Note: experiment uses the original project path scheme; if installed in a new
folder outside your model tree, pass --data-dir, --history-dir, --stock-template explicitly.
